export type Token = {
  symbol: string;
  address: string;
  decimals: number;
};
